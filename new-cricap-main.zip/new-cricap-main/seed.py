# yourapp/management/commands/seed_data.py
from django.core.management.base import BaseCommand
from yourapp.models import Kecamatan, Desa

class Command(BaseCommand):
    help = "Seed initial data for Kecamatan and Desa"

    def handle(self, *args, **kwargs):
        Kecamatan.objects.all().delete()
        Desa.objects.all().delete()

        # Tambah kecamatan
        batu = Kecamatan.objects.create(nama="Batu")
        bumiaji = Kecamatan.objects.create(nama="Bumiaji")
        junrejo = Kecamatan.objects.create(nama="Junrejo")

        # Tambah desa Batu
        desa_batu = ["Oro-oro Ombo","Pesanggrahan","Sidomulyo","Sumberejo",
                     "Ngaglik","Sisir","Songgokerto","Temas"]
        for d in desa_batu:
            Desa.objects.create(kecamatan=batu, nama=d)

        # Tambah desa Bumiaji
        desa_bumiaji = ["Bulukerto","Bumiaji","Giripurno","Gunungsari","Pandanrejo",
                        "Punten","Sumbergondo","Tulungrejo","Sumber Brantas"]
        for d in desa_bumiaji:
            Desa.objects.create(kecamatan=bumiaji, nama=d)

        # Tambah desa Junrejo
        desa_junrejo = ["Beji","Dadaprejo","Junrejo","Mojorejo","Pendem",
                        "Tlekung","Torongrejo"]
        for d in desa_junrejo:
            Desa.objects.create(kecamatan=junrejo, nama=d)

        self.stdout.write(self.style.SUCCESS("✅ Data kecamatan dan desa berhasil ditambahkan!"))
